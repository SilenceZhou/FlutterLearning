//
//  FSAppDelegate.h
//  FSCalendar
//
//  Created by CocoaPods on 02/13/2015.
//  Copyright (c) 2014 =. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
