//
//  FSCalendarSeparatorDecorationView.h
//  FSCalendar
//
//  Created by 丁文超 on 2018/10/10.
//  Copyright © 2018 wenchaoios. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FSCalendarSeparatorDecorationView : UICollectionReusableView

@end

NS_ASSUME_NONNULL_END
