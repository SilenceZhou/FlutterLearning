enum VisibilityFilter { all, active, completed }
