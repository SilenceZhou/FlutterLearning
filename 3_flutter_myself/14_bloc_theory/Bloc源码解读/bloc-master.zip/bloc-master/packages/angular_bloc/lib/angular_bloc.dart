library angular_dart;

export './src/pipes/pipes.dart';
