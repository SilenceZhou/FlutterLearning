# 0.9.0

Updated to `bloc: ^0.14.0` and Minor Updates to Documentation

# 0.8.0

Updated to `bloc: ^0.13.0` and Minor Updates to Documentation

# 0.7.0

Updated to `bloc: ^0.12.0` and Minor Updates to Documentation

# 0.6.0

Updated to `bloc: ^0.11.0` and Minor Updates to Documentation

# 0.5.0

Updated to `bloc: ^0.10.0` and Minor Updates to Documentation

# 0.4.4

Additional Minor Updates to Documentation

# 0.4.3

Updated to `bloc:^0.9.3` and Minor Updates to Documentation

# 0.4.2

Additional Minor Updates to Documentation

# 0.4.1

Minor Updates to Documentation

# 0.4.0

Updated to `bloc: ^0.9.0`

# 0.3.3

Additional Minor Updates to Documentation

# 0.3.2

Additional Minor Updates to Documentation

# 0.3.1

Minor Updates to Documentation

# 0.3.0

Updated to `bloc: ^0.8.0`

# 0.2.5

Additional Minor Updates to Documentation

# 0.2.4

Additional Minor Updates to Documentation

# 0.2.3

Updates to Documentation and Examples

# 0.2.2

Additional Minor Updates to Documentation

# 0.2.1

Minor Updates to Documentation

# 0.2.0

Updated to `bloc: ^0.7.0`

# 0.1.2

Minor Updates to Documentation

# 0.1.1

Minor Updates to Documentation

# 0.1.0

Initial Version of the library.

- Includes the ability to connect presentation layer to `Bloc` by using the `BlocPipe` Component.
